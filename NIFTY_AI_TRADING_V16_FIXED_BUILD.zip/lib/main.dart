import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'engine/trading_engine.dart';

const bg = Color(0xff050912), panel = Color(0xff0d1522), panel2 = Color(0xff111d2d);
const green = Color(0xff00e676), red = Color(0xffff4d6d), blue = Color(0xff29b6f6), yellow = Color(0xffffc107), purple = Color(0xffb26cff), cyan = Color(0xff00e5ff);

class IndexQuote { final String name; final double price, changePct; final Color color; const IndexQuote(this.name, this.price, this.changePct, this.color); }

class PaperPosition {
  String id, underlying, side, symbol, expiry;
  double strike, entryPremium, ltpPremium, delta, sl, t1, t2, t3, baseUnderlying;
  int lots, lotSize;
  bool open;
  DateTime openedAt;
  PaperPosition({required this.id, required this.underlying, required this.side, required this.symbol, required this.expiry, required this.strike, required this.entryPremium, required this.ltpPremium, required this.delta, required this.sl, required this.t1, required this.t2, required this.t3, required this.baseUnderlying, required this.lots, required this.lotSize, required this.open, required this.openedAt});
  int get qty => lots * lotSize;
  double get pnl => (ltpPremium - entryPremium) * qty;
  Map<String,dynamic> toJson()=>{'id':id,'underlying':underlying,'side':side,'symbol':symbol,'expiry':expiry,'strike':strike,'entryPremium':entryPremium,'ltpPremium':ltpPremium,'delta':delta,'sl':sl,'t1':t1,'t2':t2,'t3':t3,'baseUnderlying':baseUnderlying,'lots':lots,'lotSize':lotSize,'open':open,'openedAt':openedAt.toIso8601String()};
  static PaperPosition fromJson(Map<String,dynamic> j)=>PaperPosition(id:j['id'],underlying:j['underlying'],side:j['side'],symbol:j['symbol'],expiry:j['expiry'],strike:(j['strike'] as num).toDouble(),entryPremium:(j['entryPremium'] as num).toDouble(),ltpPremium:(j['ltpPremium'] as num).toDouble(),delta:(j['delta'] as num).toDouble(),sl:(j['sl'] as num).toDouble(),t1:(j['t1'] as num).toDouble(),t2:(j['t2'] as num).toDouble(),t3:(j['t3'] as num).toDouble(),baseUnderlying:(j['baseUnderlying'] as num).toDouble(),lots:j['lots'],lotSize:j['lotSize'],open:j['open'],openedAt:DateTime.parse(j['openedAt']));
}

class AppState extends ChangeNotifier {
  final Random rng = Random();
  Timer? timer;
  bool paper = true, connected = false, liveOrdersArmed = false, busy = false;
  String connection = 'OFFLINE', gateway = '';
  double nifty = 24247.35, vix = 12.42;
  final Map<String,double> livePrices = {'NIFTY 50':24247.35,'BANKNIFTY':54796.15,'FINNIFTY':25128.90,'MIDCPNIFTY':12895.45,'SENSEX':79688.44,'GIFT NIFTY':24280.00};
  final prices=<double>[], volumes=<double>[];
  final positions=<PaperPosition>[], journal=<Map<String,dynamic>>[];
  List<Candle> candles=[];
  AppState(){_seed(); _load();}

  void _seed(){
    var p=nifty; final now=DateTime.now().subtract(const Duration(minutes: 240));
    for(var i=0;i<240;i++){
      final o=p, move=(rng.nextDouble()-.48)*10, c=o+move, h=max(o,c)+rng.nextDouble()*6, l=min(o,c)-rng.nextDouble()*6;
      candles.add(Candle(now.add(Duration(minutes:i)),o,h,l,c,500+rng.nextDouble()*1800)); p=c;
    }
    nifty=24247.35; prices.addAll(candles.map((e)=>e.close)); volumes.addAll(candles.map((e)=>e.volume));
  }
  Future<void> _load() async { final sp=await SharedPreferences.getInstance(); paper=sp.getBool('paper')??true; liveOrdersArmed=false; final raw=sp.getString('positions'); if(raw!=null){positions.addAll((jsonDecode(raw) as List).map((e)=>PaperPosition.fromJson(e)));} notifyListeners(); }
  Future<void> _save(){return SharedPreferences.getInstance().then((sp){sp.setBool('paper',paper);sp.setString('positions',jsonEncode(positions.map((e)=>e.toJson()).toList()));});}
  void start(){timer ??= Timer.periodic(const Duration(seconds:1),(_){if(connected)_pollLive();else _simulate();});}
  void _simulate(){
    final old=nifty; nifty += (rng.nextDouble()-.49)*3.4; vix=(vix+(rng.nextDouble()-.5)*.08).clamp(9.5,24);
    livePrices['NIFTY 50']=nifty; livePrices['BANKNIFTY']=(livePrices['BANKNIFTY']!+(nifty-old)*2.1); livePrices['FINNIFTY']=(livePrices['FINNIFTY']!+(nifty-old)*.7); livePrices['MIDCPNIFTY']=(livePrices['MIDCPNIFTY']!+(nifty-old)*.35); livePrices['SENSEX']=(livePrices['SENSEX']!+(nifty-old)*4.0);
    final o=old,c=nifty; candles.add(Candle(DateTime.now(),o,max(o,c)+rng.nextDouble()*2,min(o,c)-rng.nextDouble()*2,c,500+rng.nextDouble()*1800)); if(candles.length>400)candles.removeAt(0); prices.add(c); volumes.add(candles.last.volume); if(prices.length>400)prices.removeAt(0); if(volumes.length>400)volumes.removeAt(0);
    for(final p in positions.where((x)=>x.open)){ final signed=p.side=='CE'?p.delta:-p.delta; p.ltpPremium=max(.05,p.entryPremium+(nifty-p.baseUnderlying)*signed); if((p.side=='CE'&&p.ltpPremium<=p.sl)||(p.side=='PE'&&p.ltpPremium<=p.sl)){_close(p,'AUTO SL');} }
    notifyListeners();
  }
  Future<void> _pollLive() async { try { final r=await http.get(Uri.parse('$gateway/market/indices')).timeout(const Duration(seconds:4)); if(r.statusCode!=200)throw Exception('HTTP ${r.statusCode}'); final j=jsonDecode(r.body); final data=Map<String,dynamic>.from(j['data']??{}); if(data['NIFTY 50']!=null){nifty=(data['NIFTY 50'] as num).toDouble();livePrices['NIFTY 50']=nifty;} for(final k in livePrices.keys){if(data[k]!=null)livePrices[k]=(data[k] as num).toDouble();} if(data['INDIA VIX']!=null)vix=(data['INDIA VIX'] as num).toDouble(); if(candles.isNotEmpty){final last=candles.last;candles[candles.length-1]=Candle(last.time,last.open,max(last.high,nifty),min(last.low,nifty),nifty,max(last.volume,1000));} prices.add(nifty); volumes.add(1000); if(prices.length>400)prices.removeAt(0); if(volumes.length>400)volumes.removeAt(0); connection='LIVE'; notifyListeners(); } catch(_){connection='LIVE ERROR';notifyListeners();} }
  Future<void> _loadLiveHistory() async {
    try {
      final now=DateTime.now(); final from=now.subtract(const Duration(days:1));
      String fmt(DateTime x)=>'${x.year.toString().padLeft(4,'0')}-${x.month.toString().padLeft(2,'0')}-${x.day.toString().padLeft(2,'0')} ${x.hour.toString().padLeft(2,'0')}:${x.minute.toString().padLeft(2,'0')}';
      final uri=Uri.parse('$gateway/market/candles?exchange=NSE&token=99926000&interval=ONE_MINUTE&fromdate=${Uri.encodeComponent(fmt(from))}&todate=${Uri.encodeComponent(fmt(now))}');
      final r=await http.get(uri).timeout(const Duration(seconds:10));
      if(r.statusCode!=200)return;
      final j=jsonDecode(r.body); final rows=(j['data'] as List? ?? const []);
      final parsed=<Candle>[];
      for(final row in rows){if(row is List && row.length>=6){final dt=DateTime.tryParse(row[0].toString());if(dt!=null)parsed.add(Candle(dt,(row[1] as num).toDouble(),(row[2] as num).toDouble(),(row[3] as num).toDouble(),(row[4] as num).toDouble(),(row[5] as num).toDouble()));}}
      if(parsed.isNotEmpty){candles=parsed.length>400?parsed.sublist(parsed.length-400):parsed;prices..clear()..addAll(candles.map((e)=>e.close));volumes..clear()..addAll(candles.map((e)=>e.volume));nifty=candles.last.close;}
    }catch(_){}
  }
  Future<bool> connect({required String url,required String apiKey,required String clientCode,required String pin,required String totp}) async {busy=true;notifyListeners();gateway=url.trim().replaceAll(RegExp(r'/$'), '');try{final r=await http.post(Uri.parse('$gateway/broker/login'),headers:{'Content-Type':'application/json'},body:jsonEncode({'apiKey':apiKey,'clientCode':clientCode,'pin':pin,'totp':totp})).timeout(const Duration(seconds:10));connected=r.statusCode>=200&&r.statusCode<300;connection=connected?'LIVE':'LOGIN FAILED'; if(connected) await _loadLiveHistory();}catch(_){connected=false;connection='GATEWAY ERROR';}busy=false;notifyListeners();return connected;}
  void setPaper(bool v){paper=v;if(v)liveOrdersArmed=false;_save();notifyListeners();}
  void armLive(bool v){liveOrdersArmed=v;notifyListeners();}
  void paperBuy({required String side,required String underlying,required double strike,required double premium,required double delta,required int lots,required int lotSize,required String expiry,required double slPct,required double targetR}){
    final risk=premium*slPct/100; final sl=side=='CE'?premium-risk:premium-risk; final t1=premium+risk*targetR, t2=premium+risk*targetR*1.6, t3=premium+risk*targetR*2.2;
    positions.insert(0,PaperPosition(id:DateTime.now().microsecondsSinceEpoch.toString(),underlying:underlying,side:side,symbol:'$underlying ${strike.toStringAsFixed(0)} $side',expiry:expiry,strike:strike,entryPremium:premium,ltpPremium:premium,delta:delta,sl:sl,t1:t1,t2:t2,t3:t3,baseUnderlying:nifty,lots:lots,lotSize:lotSize,open:true,openedAt:DateTime.now())); _save();notifyListeners();
  }
  Future<Map<String,dynamic>?> resolveOption({required String underlying, required double strike, required String side}) async {
    if (!connected) return null;
    try {
      final uri=Uri.parse('$gateway/market/option-contract?underlying=$underlying&strike=${strike.toStringAsFixed(2)}&side=$side');
      final r=await http.get(uri).timeout(const Duration(seconds:6));
      if(r.statusCode!=200)return null;
      final j=jsonDecode(r.body);
      return Map<String,dynamic>.from(j['data'] ?? {});
    } catch (_) { return null; }
  }
  Future<bool> liveOrder({required String side,required String tradingsymbol,required String symboltoken,required String exchange,required String ordertype,required String producttype,required String duration,required int quantity,required double price}) async {
    if(paper||!connected||!liveOrdersArmed)return false; busy=true;notifyListeners(); try{final r=await http.post(Uri.parse('$gateway/order/place'),headers:{'Content-Type':'application/json'},body:jsonEncode({'tradingsymbol':tradingsymbol,'symboltoken':symboltoken,'transactiontype':'BUY','exchange':exchange,'ordertype':ordertype,'producttype':producttype,'duration':duration,'quantity':quantity,'price':price})).timeout(const Duration(seconds:10)); final ok=r.statusCode>=200&&r.statusCode<300; busy=false;notifyListeners();return ok;}catch(_){busy=false;notifyListeners();return false;}
  }
  void exit(PaperPosition p){_close(p,'MANUAL EXIT');}
  void _close(PaperPosition p,String reason){if(!p.open)return;p.open=false;journal.insert(0,{'time':DateTime.now().toIso8601String(),'symbol':p.symbol,'side':p.side,'pnl':p.pnl,'reason':reason});_save();notifyListeners();}
  void modify(PaperPosition p,double? sl,double? t1){if(sl!=null)p.sl=sl;if(t1!=null)p.t1=t1;_save();notifyListeners();}
  double get totalPnl=>positions.fold(0,(a,p)=>a+p.pnl);
  @override void dispose(){timer?.cancel();super.dispose();}
}

void main(){final s=AppState();s.start();runApp(NiftyApp(state:s));}
class NiftyApp extends StatelessWidget{final AppState state;const NiftyApp({super.key,required this.state});@override Widget build(BuildContext c)=>AnimatedBuilder(animation:state,builder:(_,__)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true).copyWith(scaffoldBackgroundColor:bg,colorScheme:const ColorScheme.dark(primary:green,secondary:purple),inputDecorationTheme:const InputDecorationTheme(filled:true,fillColor:panel2,border:OutlineInputBorder())),home:Shell(state:state)));}

class Shell extends StatefulWidget{final AppState state;const Shell({super.key,required this.state});@override State<Shell> createState()=>_ShellState();}
class _ShellState extends State<Shell>{int page=0;void go(int p)=>setState(()=>page=p);String title(){const x=['Dashboard','Watchlist','Live Chart','AI Analysis','Option Trade','Positions','Journal','Multi-Timeframe','Support / Resistance','News & Events','Settings','Option Chain'];return x[page];}Widget body(){switch(page){case 1:return Watch(state:widget.state,go:go);case 2:return Chart(state:widget.state);case 3:return Analysis(state:widget.state);case 4:return Trade(state:widget.state);case 5:return Positions(state:widget.state);case 6:return Journal(state:widget.state);case 7:return MTF(state:widget.state);case 8:return Levels(state:widget.state);case 9:return News();case 10:return Settings(state:widget.state);case 11:return Chain(state:widget.state);default:return Home(state:widget.state,go:go);}}@override Widget build(BuildContext c){final tabs=[0,1,2,4,10];final idx=tabs.contains(page)?tabs.indexOf(page):0;return Scaffold(appBar:AppBar(title:Text('NIFTY AI • ${title()}'),backgroundColor:bg),drawer:Drawer(backgroundColor:panel,child:ListView(children:[const DrawerHeader(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('NIFTY AI TRADING',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),SizedBox(height:8),Text('V16 • Paper-first • Secure gateway',style:TextStyle(color:Colors.white54))])),...['Dashboard','Watchlist','Live Chart','AI Analysis','Option Trade','Positions','Journal','Multi-Timeframe','Support / Resistance','News & Events','Settings','Option Chain'].asMap().entries.map((e)=>ListTile(selected:page==e.key,leading:Icon([Icons.dashboard,Icons.list_alt,Icons.candlestick_chart,Icons.psychology,Icons.shopping_cart,Icons.account_balance_wallet,Icons.history,Icons.timer,Icons.show_chart,Icons.newspaper,Icons.settings,Icons.table_chart][e.key]),title:Text(e.value),onTap:(){Navigator.pop(c);go(e.key);})),])),body:SafeArea(child:body()),bottomNavigationBar:NavigationBar(backgroundColor:const Color(0xff09111d),selectedIndex:idx,onDestinationSelected:(i)=>go(tabs[i]),destinations:const[NavigationDestination(icon:Icon(Icons.home_outlined),label:'Home'),NavigationDestination(icon:Icon(Icons.list_alt),label:'Watch'),NavigationDestination(icon:Icon(Icons.candlestick_chart),label:'Chart'),NavigationDestination(icon:Icon(Icons.swap_horiz),label:'Trade'),NavigationDestination(icon:Icon(Icons.settings),label:'Settings')]));}}

Widget card(Widget w)=>Container(margin:const EdgeInsets.symmetric(horizontal:12,vertical:6),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(18),border:Border.all(color:const Color(0xff26364f))),child:w);
Widget header(String t,{String? right,Color rc=green})=>Padding(padding:const EdgeInsets.fromLTRB(16,12,16,8),child:Row(children:[Expanded(child:Text(t,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900))),if(right!=null)Text(right,style:TextStyle(color:rc,fontWeight:FontWeight.w900))]));
Widget rowx(String a,String b,{Color c=Colors.white})=>ListTile(contentPadding:EdgeInsets.zero,dense:true,title:Text(a,style:const TextStyle(fontWeight:FontWeight.w700)),trailing:Text(b,style:TextStyle(color:c,fontWeight:FontWeight.w900)));
Widget metric(String a,String b,Color c)=>Expanded(child:Container(margin:const EdgeInsets.all(3),padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:c.withOpacity(.08),borderRadius:BorderRadius.circular(12),border:Border.all(color:c.withOpacity(.25))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:Colors.white54,fontSize:11)),const SizedBox(height:4),Text(b,style:TextStyle(color:c,fontWeight:FontWeight.w900))])));

class Home extends StatelessWidget{final AppState state;final void Function(int) go;const Home({super.key,required this.state,required this.go});@override Widget build(BuildContext c){final s=TradingEngine.evaluate(state.candles);final col=s.action=='BUY CE'?green:s.action=='BUY PE'?red:yellow;return ListView(children:[header('NIFTY 50',right:state.paper?'PAPER':'LIVE',rc:state.paper?yellow:red),card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(state.nifty.toStringAsFixed(2),style:const TextStyle(color:green,fontSize:36,fontWeight:FontWeight.w900)),Text('${state.connection} • 1-second engine',style:TextStyle(color:state.connected?green:Colors.white54)),const SizedBox(height:8),SizedBox(height:80,child:MiniChart(values:state.prices))])),card(Row(children:[metric('BANKNIFTY',state.livePrices['BANKNIFTY']!.toStringAsFixed(2),green),metric('FINNIFTY',state.livePrices['FINNIFTY']!.toStringAsFixed(2),green),metric('GIFT NIFTY',state.livePrices['GIFT NIFTY']!.toStringAsFixed(2),blue),metric('VIX',state.vix.toStringAsFixed(2),yellow)])),card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('AI CONFLUENCE',style:TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:8),Row(children:[Text(s.action,style:TextStyle(color:col,fontSize:24,fontWeight:FontWeight.w900)),const Spacer(),Text('${s.score}/100',style:TextStyle(color:col,fontWeight:FontWeight.w900))]),const SizedBox(height:8),LinearProgressIndicator(value:s.score/100,minHeight:9)])),card(Column(children:[_go('LIVE CHART + INDICATORS',cyan,()=>go(2)),_go('AI DECISION ENGINE',green,()=>go(3)),_go('CALL / PUT OPTION TRADE',purple,()=>go(4)),_go('OPTION CHAIN + GREEKS',yellow,()=>go(11)),_go('POSITIONS / P&L',green,()=>go(5)),_go('TRADE JOURNAL',blue,()=>go(6)),_go('MULTI-TIMEFRAME',purple,()=>go(7)),_go('SUPPORT / RESISTANCE',yellow,()=>go(8))]))]);}}
Widget _go(String t,Color c,VoidCallback f)=>Padding(padding:const EdgeInsets.only(bottom:7),child:SizedBox(width:double.infinity,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:c),onPressed:f,child:Text(t,style:const TextStyle(fontWeight:FontWeight.w900)))));

class Watch extends StatelessWidget{final AppState state;final void Function(int) go;const Watch({super.key,required this.state,required this.go});@override Widget build(BuildContext c){final q=state.livePrices.entries.map((e)=>IndexQuote(e.key,e.value,0,green)).toList();return ListView(children:[header('WATCHLIST / INDICES',right:state.connection),card(Row(children:[metric('NIFTY 50',state.nifty.toStringAsFixed(2),green),metric('INDIA VIX',state.vix.toStringAsFixed(2),yellow)])),...q.map((x)=>card(ListTile(title:Text(x.name,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text(state.connected?'LIVE FEED':'SIMULATED PAPER FEED'),trailing:Text(x.price.toStringAsFixed(2),style:TextStyle(color:x.color,fontSize:16,fontWeight:FontWeight.w900))))),card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('MARKET BREADTH / GLOBAL CONTEXT',style:TextStyle(fontWeight:FontWeight.w900)),rowx('GIFT NIFTY',state.livePrices['GIFT NIFTY']!.toStringAsFixed(2),c:blue),rowx('India VIX',state.vix.toStringAsFixed(2),c:yellow),rowx('Feed status',state.connection,c:state.connected?green:red),FilledButton(onPressed:()=>go(2),child:const Text('OPEN LIVE CHART'))]))]);}}

class Chart extends StatefulWidget{final AppState state;const Chart({super.key,required this.state});@override State<Chart> createState()=>_ChartState();}
class _ChartState extends State<Chart>{String tf='15m';@override Widget build(BuildContext c){final s=TradingEngine.evaluate(widget.state.candles);return Column(children:[header('NIFTY 50 • $tf',right:widget.state.nifty.toStringAsFixed(2)),SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:['1m','5m','15m','1H','D'].map((x)=>Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:ChoiceChip(label:Text(x),selected:tf==x,onSelected:(_){setState(()=>tf=x);}))).toList())),Expanded(child:card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('PRICE • VOLUME • VWAP • EMA • ALLIGATOR',style:const TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:8),Expanded(child:MarketChart(candles:widget.state.candles)),const SizedBox(height:8),Wrap(spacing:8,children:[_tag('VWAP',blue),_tag('EMA 9/20/50',purple),_tag('Alligator',green),_tag('Volume',yellow),_tag('ATR',cyan),_tag('FVG/BOS',red)]),const SizedBox(height:6),Text('AI: ${s.action} • score ${s.score}/100',style:TextStyle(color:s.action=='BUY CE'?green:s.action=='BUY PE'?red:yellow,fontWeight:FontWeight.w900))])))]);}}
Widget _tag(String s,Color c)=>Chip(label:Text(s,style:TextStyle(color:c,fontSize:11,fontWeight:FontWeight.w800)),backgroundColor:c.withOpacity(.08));
class MiniChart extends StatelessWidget{final List<double> values;const MiniChart({super.key,required this.values});@override Widget build(BuildContext c)=>CustomPaint(painter:LinePainter(values));}
class LinePainter extends CustomPainter{final List<double> v;LinePainter(this.v);@override void paint(Canvas c,Size s){if(v.length<2)return;final p=Paint()..color=green..strokeWidth=2;final a=v.length>100?v.sublist(v.length-100):v;final mn=a.reduce(min),mx=a.reduce(max),d=max(1,mx-mn);for(var i=1;i<a.length;i++){final x1=(i-1)/(a.length-1)*s.width,x2=i/(a.length-1)*s.width,y1=s.height-(a[i-1]-mn)/d*s.height,y2=s.height-(a[i]-mn)/d*s.height;c.drawLine(Offset(x1,y1),Offset(x2,y2),p);}}@override bool shouldRepaint(covariant LinePainter old)=>true;}
class MarketChart extends StatelessWidget{final List<Candle> candles;const MarketChart({super.key,required this.candles});@override Widget build(BuildContext c)=>CustomPaint(painter:CandlePainter(candles),size:Size.infinite);}
class CandlePainter extends CustomPainter{final List<Candle> candles;CandlePainter(this.candles);@override void paint(Canvas c,Size s){if(candles.length<2)return;final n=min(80,candles.length),a=candles.sublist(candles.length-n);final lo=a.map((x)=>x.low).reduce(min),hi=a.map((x)=>x.high).reduce(max),d=max(1,hi-lo),cw=s.width/n;for(var i=0;i<n;i++){final x=a[i],cx=i*cw+cw/2,oy=s.height*.72-(x.open-lo)/d*s.height*.62,cy=s.height*.72-(x.close-lo)/d*s.height*.62,hy=s.height*.72-(x.high-lo)/d*s.height*.62,ly=s.height*.72-(x.low-lo)/d*s.height*.62,up=x.close>=x.open,col=up?green:red;final p=Paint()..color=col..strokeWidth=1.3;c.drawLine(Offset(cx,hy),Offset(cx,ly),p);c.drawRect(Rect.fromLTRB(cx-cw*.28,min(oy,cy),cx+cw*.28,max(oy,cy)+1),p);final vh=(x.volume/(a.map((z)=>z.volume).reduce(max))).clamp(.02,.22)*s.height;c.drawRect(Rect.fromLTWH(i*cw+cw*.2,s.height-vh,cw*.6,vh),Paint()..color=col.withOpacity(.24));}}@override bool shouldRepaint(covariant CandlePainter old)=>true;}

class Analysis extends StatelessWidget{final AppState state;const Analysis({super.key,required this.state});@override Widget build(BuildContext c){final s=TradingEngine.evaluate(state.candles);final col=s.action=='BUY CE'?green:s.action=='BUY PE'?red:yellow;return ListView(children:[header('AI DECISION ENGINE',right:'${s.score}/100',rc:col),card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(s.action,style:TextStyle(color:col,fontSize:30,fontWeight:FontWeight.w900)),const SizedBox(height:8),LinearProgressIndicator(value:s.score/100,minHeight:10),rowx('EMA 9 / 20 / 50','${s.ema9.toStringAsFixed(1)} / ${s.ema20.toStringAsFixed(1)} / ${s.ema50.toStringAsFixed(1)}'),rowx('VWAP',s.vwap.toStringAsFixed(1)),rowx('RSI 14',s.rsi.toStringAsFixed(1)),rowx('Alligator','${s.jaw.toStringAsFixed(1)} / ${s.teeth.toStringAsFixed(1)} / ${s.lips.toStringAsFixed(1)}'),rowx('Volume / Avg20','${s.volume.toStringAsFixed(0)} / ${s.avgVolume.toStringAsFixed(0)}'),rowx('ATR 14',s.atr.toStringAsFixed(2))])),card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('CONFLUENCE REASONS',style:TextStyle(fontWeight:FontWeight.w900)),...s.reasons.map((r)=>ListTile(dense:true,contentPadding:EdgeInsets.zero,leading:Icon(r.contains('below')||r.contains('bearish')||r.contains('<')?Icons.cancel:Icons.check_circle,color:r.contains('below')||r.contains('bearish')||r.contains('<')?red:green),title:Text(r)))])),card(Column(children:[rowx('Entry',s.entry.toStringAsFixed(2)),rowx('Stop Loss',s.sl.toStringAsFixed(2),c:red),rowx('T1',s.t1.toStringAsFixed(2),c:green),rowx('T2',s.t2.toStringAsFixed(2),c:green),rowx('T3',s.t3.toStringAsFixed(2),c:green),const Text('Signal is a technical confluence score, not a probability or profit guarantee.',style:TextStyle(color:Colors.white54,fontSize:11))]))]);}}

class Trade extends StatefulWidget{final AppState state;const Trade({super.key,required this.state});@override State<Trade> createState()=>_TradeState();}
class _TradeState extends State<Trade>{String side='CE',underlying='NIFTY';double premium=48,strike=24250,delta=.65,slPct=25,targetR=1.5;int lots=1;String expiry='CURRENT';final premiumCtl=TextEditingController(text:'48');final strikeCtl=TextEditingController(text:'24250');@override void dispose(){premiumCtl.dispose();strikeCtl.dispose();super.dispose();}
 int get lotSize=>underlying=='NIFTY'?65:underlying=='BANKNIFTY'?30:underlying=='FINNIFTY'?60:120;
 @override Widget build(BuildContext c){final s=TradingEngine.evaluate(widget.state.candles);final col=side=='CE'?green:red;return ListView(children:[header('OPTION BUY / ORDER',right:widget.state.paper?'PAPER':'LIVE',rc:widget.state.paper?yellow:red),card(Row(children:[Expanded(child:FilledButton(style:FilledButton.styleFrom(backgroundColor:green),onPressed:()=>setState(()=>side='CE'),child:const Text('CALL (CE)'))),const SizedBox(width:8),Expanded(child:FilledButton(style:FilledButton.styleFrom(backgroundColor:red),onPressed:()=>setState(()=>side='PE'),child:const Text('PUT (PE)')))])),card(Column(children:[DropdownButtonFormField<String>(value:underlying,items:['NIFTY','BANKNIFTY','FINNIFTY','MIDCPNIFTY'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(x){if(x!=null)setState(()=>underlying=x);},decoration:const InputDecoration(labelText:'Underlying')),TextField(controller:strikeCtl,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Strike'),onChanged:(v)=>strike=double.tryParse(v)??strike),TextField(controller:premiumCtl,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Option LTP / Paper Premium'),onChanged:(v)=>premium=double.tryParse(v)??premium),Slider(value:delta,min:.2,max:.9,divisions:14,label:delta.toStringAsFixed(2),onChanged:(v)=>setState(()=>delta=v)),rowx('Buy Delta',delta.toStringAsFixed(2),c:cyan),rowx('Lot Size',lotSize.toString(),c:yellow),rowx('Quantity','$lotSize × $lots = ${lotSize*lots}'),Row(children:[const Text('Lots'),IconButton(onPressed:()=>setState((){if(lots>1)lots--;}),icon:const Icon(Icons.remove)),Text('$lots'),IconButton(onPressed:()=>setState(()=>lots++),icon:const Icon(Icons.add))]),rowx('AI suggestion',s.action,c:s.action=='BUY CE'?green:s.action=='BUY PE'?red:yellow),rowx('AI score','${s.score}/100'),const SizedBox(height:8),SizedBox(width:double.infinity,child:FilledButton(style:FilledButton.styleFrom(backgroundColor:col),onPressed:()async{if(widget.state.paper){widget.state.paperBuy(side:side,underlying:underlying,strike:strike,premium:premium,delta:delta,lots:lots,lotSize:lotSize,expiry:expiry,slPct:slPct,targetR:targetR);if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Paper BUY $side created • ${lotSize*lots} qty')));}else{if(!widget.state.liveOrdersArmed){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Arm LIVE ORDERS in Settings first.')));return;}final contract=await widget.state.resolveOption(underlying:underlying,strike:strike,side:side);
if(contract==null){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Option contract not resolved from broker instrument master.')));return;}
final ok=await widget.state.liveOrder(side:side,tradingsymbol:contract['tradingsymbol'],symboltoken:contract['symboltoken'].toString(),exchange:contract['exchange']??'NFO',ordertype:'MARKET',producttype:'CARRYFORWARD',duration:'DAY',quantity:lotSize*lots,price:0);if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(ok?'LIVE ORDER ACCEPTED':'LIVE ORDER FAILED')));}},child:Text(widget.state.paper?'PAPER BUY $side':'LIVE BUY $side',style:const TextStyle(fontWeight:FontWeight.w900))))]))]);}}

class Positions extends StatelessWidget{final AppState state;const Positions({super.key,required this.state});@override Widget build(BuildContext c)=>ListView(children:[header('POSITIONS / P&L',right:'₹${state.totalPnl.toStringAsFixed(0)}',rc:state.totalPnl>=0?green:red),if(state.positions.isEmpty)card(const Text('No paper positions yet.')), ...state.positions.map((p)=>card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Expanded(child:Text('${p.side} • ${p.symbol}',style:const TextStyle(fontWeight:FontWeight.w900))),Text(p.open?'OPEN':'CLOSED',style:TextStyle(color:p.open?green:Colors.white54,fontWeight:FontWeight.w900))]),rowx('Entry / LTP','${p.entryPremium.toStringAsFixed(2)} / ${p.ltpPremium.toStringAsFixed(2)}'),rowx('P&L','₹${p.pnl.toStringAsFixed(2)}',c:p.pnl>=0?green:red),rowx('SL / T1 / T2 / T3','${p.sl.toStringAsFixed(2)} / ${p.t1.toStringAsFixed(2)} / ${p.t2.toStringAsFixed(2)}'),if(p.open)Row(children:[OutlinedButton(onPressed:()=>state.exit(p),child:const Text('EXIT')),const SizedBox(width:8),OutlinedButton(onPressed:()=>_modify(c,state,p),child:const Text('MODIFY'))])])))]);}
Future<void> _modify(BuildContext c,AppState s,PaperPosition p) async {
  final sl = TextEditingController(text: p.sl.toStringAsFixed(2));
  final t1 = TextEditingController(text: p.t1.toStringAsFixed(2));
  await showDialog<void>(
    context: c,
    builder: (_) => AlertDialog(
      title: const Text('Modify Risk'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(controller: sl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'SL')),
          TextField(controller: t1, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'T1')),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
        FilledButton(
          onPressed: () {
            s.modify(p, double.tryParse(sl.text), double.tryParse(t1.text));
            Navigator.pop(c);
          },
          child: const Text('Save'),
        ),
      ],
    ),
  );
  sl.dispose();
  t1.dispose();
}

class Journal extends StatelessWidget{final AppState state;const Journal({super.key,required this.state});@override Widget build(BuildContext c)=>ListView(children:[header('TRADE JOURNAL / HISTORY'),if(state.journal.isEmpty)card(const Text('Closed paper trades will appear here.')), ...state.journal.map((x)=>card(rowx('${x['side']} • ${x['symbol']}', '₹${(x['pnl'] as num).toDouble().toStringAsFixed(2)}',c:(x['pnl'] as num).toDouble()>=0?green:red))) ]);}
class MTF extends StatelessWidget{final AppState state;const MTF({super.key,required this.state});@override Widget build(BuildContext c){final s=TradingEngine.evaluate(state.candles);return ListView(children:[header('MULTI-TIMEFRAME ANALYSIS'),...['1 MIN','5 MIN','15 MIN','1 HOUR','DAILY'].asMap().entries.map((e){final double score=(s.score + (e.key-2)*3).clamp(0,100).toDouble();return card(Column(children:[Row(children:[Expanded(child:Text(e.value,style:const TextStyle(fontWeight:FontWeight.w900))),Text(score>=60?'BULLISH':score<=40?'BEARISH':'NEUTRAL',style:TextStyle(color:score>=60?green:score<=40?red:yellow,fontWeight:FontWeight.w900))]),LinearProgressIndicator(value:score/100,minHeight:7),const SizedBox(height:6),const Text('VWAP • EMA • Alligator • Volume • Structure • Momentum',style:TextStyle(color:Colors.white54,fontSize:11))]));}) ]);}}
class Levels extends StatelessWidget{final AppState state;const Levels({super.key,required this.state});@override Widget build(BuildContext c){final p=state.nifty;final a=TradingEngine.atr(state.candles,14);return ListView(children:[header('SUPPORT / RESISTANCE / STRUCTURE'),card(rowx('R2',(p+a*2.0).toStringAsFixed(2),c:red)),card(rowx('R1',(p+a).toStringAsFixed(2),c:yellow)),card(Center(child:Text(p.toStringAsFixed(2),style:const TextStyle(color:green,fontSize:30,fontWeight:FontWeight.w900)))),card(rowx('S1',(p-a).toStringAsFixed(2),c:yellow)),card(rowx('S2',(p-a*2).toStringAsFixed(2),c:green)),card(const Text('BOS • CHoCH • FVG • Liquidity sweep • Previous High/Low • Fibonacci 38.2 / 50 / 61.8',style:TextStyle(height:1.7,color:Colors.white70))) ]);}}
class News extends StatelessWidget{const News({super.key});@override Widget build(BuildContext c)=>ListView(children:[header('NEWS & EVENTS'),card(const ListTile(leading:Icon(Icons.info,color:cyan),title:Text('Live news connector ready'),subtitle:Text('Connect a news provider in the gateway for current headlines.'))),...const[['RBI / India','DOMESTIC'],['US Fed / Data','MACRO'],['Crude / Hormuz','GLOBAL RISK'],['Tariffs / Trade','GLOBAL RISK'],['Corporate Results','EARNINGS']].map((x)=>card(ListTile(leading:Icon(Icons.bolt,color:x[1]=='GLOBAL RISK'?red:yellow),title:Text(x[0],style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text(x[1]))))]);}

class Settings extends StatefulWidget{final AppState state;const Settings({super.key,required this.state});@override State<Settings> createState()=>_SettingsState();}
class _SettingsState extends State<Settings>{final gateway=TextEditingController(),api=TextEditingController(),client=TextEditingController(),pin=TextEditingController(),totp=TextEditingController();@override void dispose(){gateway.dispose();api.dispose();client.dispose();pin.dispose();totp.dispose();super.dispose();}@override Widget build(BuildContext c)=>ListView(children:[header('SETTINGS / BROKER'),card(Column(children:[SwitchListTile(title:const Text('Paper Trading'),subtitle:const Text('Safe default — simulated execution'),value:widget.state.paper,onChanged:widget.state.setPaper),SwitchListTile(title:const Text('ARM REAL-MONEY ORDERS'),subtitle:const Text('Second safety gate for live orders'),value:widget.state.liveOrdersArmed,onChanged:widget.state.paper?null:(v){if(v){_confirmArm(c);}else widget.state.armLive(false);}),TextField(controller:gateway,decoration:const InputDecoration(labelText:'Secure Gateway HTTPS URL')),TextField(controller:api,obscureText:true,decoration:const InputDecoration(labelText:'Angel One API Key')),TextField(controller:client,decoration:const InputDecoration(labelText:'Client Code')),TextField(controller:pin,obscureText:true,decoration:const InputDecoration(labelText:'PIN')),TextField(controller:totp,obscureText:true,decoration:const InputDecoration(labelText:'Current 6-digit TOTP')),const SizedBox(height:10),SizedBox(width:double.infinity,child:FilledButton(onPressed: widget.state.busy ? null : _connect,child:Text(widget.state.busy?'CONNECTING…':'CONNECT LIVE FEED'))),rowx('Connection',widget.state.connection,c:widget.state.connected?green:red),rowx('Paper',widget.state.paper?'ON':'OFF',c:widget.state.paper?green:red),const Text('Broker secrets stay behind the secure gateway; do not hard-code credentials in the APK.',style:TextStyle(color:Colors.white54,fontSize:11))]))]);
Future<void> _connect()async{final ok=await widget.state.connect(url:gateway.text,apiKey:api.text,clientCode:client.text,pin:pin.text,totp:totp.text);if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(ok?'SmartAPI session connected':'Connection failed')));}
Future<void> _confirmArm(BuildContext c) async {
  final ok = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      title: const Text('Enable real-money orders?'),
      content: const Text('This allows the Trade page to send BUY orders through your configured gateway. Verify symbol, quantity, price and account before every order.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('CANCEL')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('ARM LIVE')),
      ],
    ),
  );
  if (ok == true) widget.state.armLive(true);
}
}

class Chain extends StatelessWidget{final AppState state;const Chain({super.key,required this.state});@override Widget build(BuildContext c){final s=TradingEngine.evaluate(state.candles);final atm=(state.nifty/50).round()*50;final rows=List.generate(11,(i)=>atm+(i-5)*50);return ListView(children:[header('OPTION CHAIN / GREEKS',right:state.connected?'LIVE':'PAPER',rc:state.connected?green:yellow),card(Row(children:[metric('ATM',atm.toString(),cyan),metric('AI',s.action, s.action=='BUY CE'?green:s.action=='BUY PE'?red:yellow),metric('PCR','—',purple)])),card(const Text('STRIKE          CE LTP     CE Δ       PE Δ      PE LTP',style:TextStyle(fontWeight:FontWeight.w900))),...rows.map((k){final d=((state.nifty-k)/1000).clamp(-.65,.65);final ce=max(.05,48+(state.nifty-k)*.55),pe=max(.05,48+(k-state.nifty)*.55);return card(Row(children:[Expanded(child:Text(k.toString(),style:const TextStyle(fontWeight:FontWeight.w900))),Expanded(child:Text(ce.toStringAsFixed(2),style:const TextStyle(color:green))),Expanded(child:Text(d.toStringAsFixed(2))),Expanded(child:Text((-d).toStringAsFixed(2))),Expanded(child:Text(pe.toStringAsFixed(2),style:const TextStyle(color:red)))]));}),card(const Text('LIVE mode can populate real option Greeks from the Angel One Option Greek API and live option tokens through the secure gateway.',style:TextStyle(color:Colors.white54,fontSize:11))) ]);}}
