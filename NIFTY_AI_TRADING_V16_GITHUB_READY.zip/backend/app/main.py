import json
import os
import threading
import time
from datetime import datetime
from typing import Any

import requests
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from SmartApi.smartConnect import SmartConnect

app = FastAPI(title='NIFTY AI Secure Trading Gateway', version='2.0.0')

SESSION: SmartConnect | None = None
CLIENT_CODE = ''
API_KEY = ''
SESSION_LOCK = threading.Lock()
MASTER_CACHE: list[dict[str, Any]] = []
MASTER_TS = 0.0

MASTER_URL = 'https://margincalculator.angelone.in/OpenAPI_File/files/OpenAPIScripMaster.json'

class Login(BaseModel):
    apiKey: str = Field(min_length=5)
    clientCode: str = Field(min_length=1)
    pin: str = Field(min_length=1)
    totp: str = Field(min_length=6, max_length=6)

class Order(BaseModel):
    tradingsymbol: str
    symboltoken: str
    transactiontype: str = 'BUY'
    exchange: str = 'NFO'
    ordertype: str = 'MARKET'
    producttype: str = 'INTRADAY'
    duration: str = 'DAY'
    quantity: int = Field(gt=0)
    price: float = 0
    triggerprice: float = 0


def require_session() -> SmartConnect:
    if SESSION is None:
        raise HTTPException(401, 'Broker session is not connected')
    return SESSION


def load_master() -> list[dict[str, Any]]:
    global MASTER_CACHE, MASTER_TS
    if MASTER_CACHE and time.time() - MASTER_TS < 900:
        return MASTER_CACHE
    try:
        r = requests.get(MASTER_URL, timeout=20)
        r.raise_for_status()
        MASTER_CACHE = r.json()
        MASTER_TS = time.time()
        return MASTER_CACHE
    except Exception as e:
        if MASTER_CACHE:
            return MASTER_CACHE
        raise HTTPException(502, f'Instrument master unavailable: {e}')


@app.get('/health')
def health():
    return {'ok': True, 'connected': SESSION is not None, 'clientCode': CLIENT_CODE or None}


@app.post('/broker/login')
def login(body: Login):
    global SESSION, CLIENT_CODE, API_KEY
    with SESSION_LOCK:
        try:
            api = SmartConnect(api_key=body.apiKey)
            result = api.generateSession(body.clientCode, body.pin, body.totp)
            if not result or not result.get('status'):
                raise HTTPException(401, result.get('message', 'SmartAPI login failed') if result else 'SmartAPI login failed')
            SESSION = api
            CLIENT_CODE = body.clientCode
            API_KEY = body.apiKey
            return {'ok': True, 'clientCode': CLIENT_CODE, 'message': 'SmartAPI session connected'}
        except HTTPException:
            raise
        except Exception as e:
            SESSION = None
            raise HTTPException(502, f'SmartAPI login error: {e}')


@app.post('/broker/logout')
def logout():
    global SESSION
    if SESSION is not None:
        try:
            SESSION.terminateSession(CLIENT_CODE)
        except Exception:
            pass
    SESSION = None
    return {'ok': True}


@app.get('/market/ltp')
def ltp(exchange: str, symbol: str, token: str):
    api = require_session()
    try:
        return api.ltpData(exchange, symbol, token)
    except Exception as e:
        raise HTTPException(502, f'LTP error: {e}')


@app.get('/market/indices')
def indices():
    api = require_session()
    raw = os.getenv('INDEX_TOKENS_JSON', '{}')
    try:
        mapping = json.loads(raw)
    except json.JSONDecodeError:
        raise HTTPException(500, 'INDEX_TOKENS_JSON is invalid')
    if not mapping:
        mapping = {
                'NIFTY 50': {'exchange': 'NSE', 'symbol': 'Nifty 50', 'token': '99926000'},
                'BANKNIFTY': {'exchange': 'NSE', 'symbol': 'Nifty Bank', 'token': '99926009'},
                'FINNIFTY': {'exchange': 'NSE', 'symbol': 'Nifty Fin Service', 'token': '99926037'},
                'MIDCPNIFTY': {'exchange': 'NSE', 'symbol': 'NIFTY MID SELECT', 'token': '99926074'},
                'INDIA VIX': {'exchange': 'NSE', 'symbol': 'India VIX', 'token': '99926017'},
                'SENSEX': {'exchange': 'BSE', 'symbol': 'SENSEX', 'token': '99919000'},
            }
    out: dict[str, float] = {}
    for name, cfg in mapping.items():
        try:
            res = api.ltpData(cfg['exchange'], cfg['symbol'], str(cfg['token']))
            data = (res or {}).get('data') or {}
            if data.get('ltp') is not None:
                out[name] = float(data['ltp'])
        except Exception:
            continue
    return {'status': True, 'data': out}


@app.get('/market/search')
def search(exchange: str, query: str):
    api = require_session()
    try:
        return api.searchScrip(exchange, query)
    except Exception as e:
        raise HTTPException(502, f'Search error: {e}')


@app.get('/market/candles')
def candles(exchange: str, token: str, interval: str = 'ONE_MINUTE', fromdate: str = '', todate: str = ''):
    api = require_session()
    if not fromdate or not todate:
        raise HTTPException(400, 'fromdate and todate are required')
    try:
        return api.getCandleData({'exchange': exchange, 'symboltoken': token, 'interval': interval, 'fromdate': fromdate, 'todate': todate})
    except Exception as e:
        raise HTTPException(502, f'Candle error: {e}')


@app.get('/market/option-contract')
def option_contract(underlying: str, strike: float, side: str):
    side = side.upper()
    if side not in {'CE', 'PE'}:
        raise HTTPException(400, 'side must be CE or PE')
    master = load_master()
    today = datetime.now().date()
    candidates = []
    for x in master:
        if x.get('instrumenttype') != side:
            continue
        if x.get('name') != underlying:
            continue
        try:
            xs = float(x.get('strike', 0)) / 100
            if abs(xs - strike) > 0.01:
                continue
            expiry = datetime.strptime(x['expiry'], '%d%b%Y').date()
            if expiry >= today:
                candidates.append((expiry, x))
        except Exception:
            continue
    if not candidates:
        raise HTTPException(404, 'Option contract not found in current instrument master')
    candidates.sort(key=lambda z: z[0])
    expiry, x = candidates[0]
    return {'ok': True, 'data': {'tradingsymbol': x['symbol'], 'symboltoken': x['token'], 'expiry': x['expiry'], 'lotSize': int(float(x.get('lotsize', 0))), 'exchange': x.get('exch_seg', 'NFO')}}


@app.post('/market/option-greek')
def option_greek(name: str, expirydate: str):
    api = require_session()
    try:
        return api.optionGreek({'name': name, 'expirydate': expirydate})
    except Exception as e:
        raise HTTPException(502, f'Option Greek error: {e}')


@app.get('/account/orderbook')
def orderbook():
    try:
        return require_session().orderBook()
    except Exception as e:
        raise HTTPException(502, f'Order book error: {e}')


@app.get('/account/positions')
def positions():
    try:
        return require_session().position()
    except Exception as e:
        raise HTTPException(502, f'Position error: {e}')


@app.get('/account/trades')
def trades():
    try:
        return require_session().tradeBook()
    except Exception as e:
        raise HTTPException(502, f'Trade book error: {e}')


@app.post('/order/place')
def place_order(body: Order):
    api = require_session()
    if body.transactiontype not in {'BUY', 'SELL'}:
        raise HTTPException(400, 'Invalid transaction type')
    params = body.model_dump()
    params['squareoff'] = '0'
    params['stoploss'] = '0'
    try:
        order_id = api.placeOrderFullResponse(params)
        if not order_id:
            raise HTTPException(502, 'SmartAPI returned no order response')
        return order_id
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, f'Order placement error: {e}')


@app.post('/order/modify')
def modify_order(body: dict):
    try:
        return require_session().modifyOrder(body)
    except Exception as e:
        raise HTTPException(502, f'Order modify error: {e}')


@app.post('/order/cancel')
def cancel_order(order_id: str, variety: str = 'NORMAL'):
    try:
        return require_session().cancelOrder(order_id, variety)
    except Exception as e:
        raise HTTPException(502, f'Order cancel error: {e}')
