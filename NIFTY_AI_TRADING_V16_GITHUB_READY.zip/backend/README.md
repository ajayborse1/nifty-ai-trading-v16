# Secure Angel One Gateway

Run this service on your HTTPS server with the registered static IPv4 used for broker order APIs.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

For production, put it behind HTTPS and a reverse proxy. Never commit API keys, PINs, TOTP seeds, JWTs or refresh tokens.

The gateway keeps the SmartAPI session server-side and exposes only the app functions needed by the mobile client.
