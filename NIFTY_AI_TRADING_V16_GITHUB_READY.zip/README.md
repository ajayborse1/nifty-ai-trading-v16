# NIFTY AI Trading V16 — Complete Flutter Project

This is the actual Flutter source project, not a screenshot/template.

## Included working local features
- Colourful professional dark trading UI
- Dashboard
- NIFTY / BANKNIFTY / FINNIFTY / MIDCPNIFTY / SENSEX / GIFT NIFTY / India VIX watchlist
- 1-second paper market simulator
- Candlestick + volume chart
- VWAP, EMA 9/20/50, RSI, ATR, Alligator, volume expansion
- BOS / CHoCH / FVG / structure confluence
- AI-style deterministic decision score: BUY CE / BUY PE / WAIT
- Entry, SL, T1/T2/T3
- CE/PE paper buying with current NIFTY lot size default of 65
- Paper P&L based on option delta rather than underlying points
- Persistent paper positions and journal
- Exit + Modify risk controls
- Multi-timeframe page
- Support/resistance/structure page
- Option chain/Greeks presentation
- Broker settings with a second live-order safety gate

## Live Angel One architecture
The Android app talks to a secure gateway. Broker API key, client code, PIN and TOTP are not embedded in the APK. The gateway uses the official SmartAPI Python client.

Gateway endpoints include:
- POST /broker/login
- GET /market/indices
- GET /market/ltp
- GET /market/candles
- GET /market/search
- GET /market/option-contract
- POST /market/option-greek
- GET /account/orderbook
- GET /account/positions
- GET /account/trades
- POST /order/place
- POST /order/modify
- POST /order/cancel

For real orders, deploy the gateway from the static IPv4 registered for the broker's order API and use HTTPS. Keep the live-order arm OFF until you have verified the account, contract, quantity, order type and price.

## GitHub
Only commit the project files and `.github/workflows/build.yml`. Do not upload a ZIP and expect the workflow to unzip it.
The workflow regenerates a complete Android wrapper before building, so missing `gradlew`/wrapper files do not block the APK build.
