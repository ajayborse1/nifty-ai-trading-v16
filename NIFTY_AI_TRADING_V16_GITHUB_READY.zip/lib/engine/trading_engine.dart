import 'dart:math';

class Candle {
  final DateTime time;
  final double open, high, low, close, volume;
  Candle(this.time, this.open, this.high, this.low, this.close, this.volume);
}

class Signal {
  final String action;
  final int score;
  final List<String> reasons;
  final double ema9, ema20, ema50, rsi, vwap, atr, jaw, teeth, lips, volume, avgVolume;
  final double entry, sl, t1, t2, t3;
  Signal({required this.action, required this.score, required this.reasons,
    required this.ema9, required this.ema20, required this.ema50, required this.rsi,
    required this.vwap, required this.atr, required this.jaw, required this.teeth,
    required this.lips, required this.volume, required this.avgVolume,
    required this.entry, required this.sl, required this.t1, required this.t2, required this.t3});
}

class TradingEngine {
  static double ema(List<double> x, int n) {
    if (x.isEmpty) return 0;
    var e = x.first;
    final k = 2 / (n + 1);
    for (final v in x.skip(1)) e = v * k + e * (1 - k);
    return e;
  }

  static double sma(List<double> x, int n) {
    if (x.isEmpty) return 0;
    final a = x.length <= n ? x : x.sublist(x.length - n);
    return a.reduce((a, b) => a + b) / a.length;
  }

  static double rsi(List<double> x, int n) {
    if (x.length <= n) return 50;
    double gain = 0, loss = 0;
    for (var i = x.length - n; i < x.length; i++) {
      final d = x[i] - x[i - 1];
      if (d >= 0) gain += d; else loss -= d;
    }
    if (loss == 0) return 100;
    final rs = gain / loss;
    return 100 - (100 / (1 + rs));
  }

  static double atr(List<Candle> c, int n) {
    if (c.length < 2) return 0;
    final tr = <double>[];
    for (var i = 1; i < c.length; i++) {
      final cur = c[i], prev = c[i - 1];
      tr.add(max(cur.high - cur.low, max((cur.high - prev.close).abs(), (cur.low - prev.close).abs())));
    }
    return sma(tr, n);
  }

  static double vwap(List<Candle> c) {
    double pv = 0, vol = 0;
    for (final x in c) {
      final tp = (x.high + x.low + x.close) / 3;
      pv += tp * x.volume;
      vol += x.volume;
    }
    return vol == 0 ? (c.isEmpty ? 0 : c.last.close) : pv / vol;
  }

  static List<double> alligator(List<double> x) => [sma(x, 13), sma(x, 8), sma(x, 5)];

  static bool bullishStructure(List<Candle> c) {
    if (c.length < 6) return false;
    final a = c[c.length - 1], b = c[c.length - 3], d = c[c.length - 5];
    return a.high > b.high && b.high > d.high && a.low > b.low;
  }

  static bool bearishStructure(List<Candle> c) {
    if (c.length < 6) return false;
    final a = c[c.length - 1], b = c[c.length - 3], d = c[c.length - 5];
    return a.low < b.low && b.low < d.low && a.high < b.high;
  }

  static bool bullFvg(List<Candle> c) => c.length >= 3 && c.last.low > c[c.length - 3].high;
  static bool bearFvg(List<Candle> c) => c.length >= 3 && c.last.high < c[c.length - 3].low;

  static Signal evaluate(List<Candle> c) {
    if (c.isEmpty) {
      return Signal(action: 'WAIT', score: 50, reasons: const ['Waiting for market data'], ema9: 0, ema20: 0, ema50: 0, rsi: 50, vwap: 0, atr: 0, jaw: 0, teeth: 0, lips: 0, volume: 0, avgVolume: 0, entry: 0, sl: 0, t1: 0, t2: 0, t3: 0);
    }
    final x = c.map((e) => e.close).toList(), p = x.last;
    final e9 = ema(x, 9), e20 = ema(x, 20), e50 = ema(x, 50), r = rsi(x, 14), w = vwap(c), a = atr(c, 14);
    final ag = alligator(x), jaw = ag[0], teeth = ag[1], lips = ag[2], vol = c.last.volume, av = sma(c.map((e) => e.volume).toList(), 20);
    var score = 50;
    final reasons = <String>[];
    void add(int n, String reason) { score += n; reasons.add(reason); }
    if (p > w) add(7, 'Price above VWAP'); else add(-7, 'Price below VWAP');
    if (e9 > e20) add(8, 'EMA 9 > EMA 20'); else add(-8, 'EMA 9 < EMA 20');
    if (e20 > e50) add(8, 'EMA 20 > EMA 50'); else add(-8, 'EMA 20 < EMA 50');
    if (lips > teeth && teeth > jaw) add(10, 'Alligator bullish alignment');
    else if (lips < teeth && teeth < jaw) add(-10, 'Alligator bearish alignment');
    else reasons.add('Alligator mixed');
    if (av > 0 && vol >= av * 1.2) add(c.last.close >= c[c.length - 2].close ? 7 : -7, 'Volume expansion');
    else reasons.add('Volume not expanded');
    if (r >= 55 && r <= 70) add(5, 'RSI bullish zone'); else if (r < 45) add(-5, 'RSI bearish zone'); else reasons.add('RSI neutral');
    if (bullishStructure(c)) add(8, 'Bullish market structure'); else if (bearishStructure(c)) add(-8, 'Bearish market structure'); else reasons.add('Structure mixed');
    if (bullFvg(c)) add(3, 'Bullish FVG'); else if (bearFvg(c)) add(-3, 'Bearish FVG');
    score = score.clamp(0, 100);
    final action = score >= 72 ? 'BUY CE' : score <= 28 ? 'BUY PE' : 'WAIT';
    final risk = max(a * 1.2, p * 0.0025);
    final sl = action == 'BUY PE' ? p + risk : p - risk;
    final t1 = action == 'BUY PE' ? p - risk * 1.5 : p + risk * 1.5;
    final t2 = action == 'BUY PE' ? p - risk * 2.2 : p + risk * 2.2;
    final t3 = action == 'BUY PE' ? p - risk * 3 : p + risk * 3;
    return Signal(action: action, score: score, reasons: reasons, ema9: e9, ema20: e20, ema50: e50, rsi: r, vwap: w, atr: a, jaw: jaw, teeth: teeth, lips: lips, volume: vol, avgVolume: av, entry: p, sl: sl, t1: t1, t2: t2, t3: t3);
  }
}
