package com.example.nifty_ai_trading
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()